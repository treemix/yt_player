
var play_list = [
    {
        title: "News and Community Spotlight | April 9, 2020 | Unreal Engine",
        id: "EGcTPWXgR_Y"
    },
    {
        title: "News and Community Spotlight | April 2, 2020 | Unreal Engine",
        id: "oxt0HZxgDp8"
    },
    {
        title: "Real-time skills at the University of Hertfordshire | Project Spotlight | Unreal Engine",
        id: "g1iy_BmgUbY"
    },
    {
        title: "News and Community Spotlight | March 26, 2020 | Unreal Engine",
        id: "SvLZP93Sh88"
    },
];